//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.earth2me.essentials;

import com.earth2me.essentials.Enchantments;
import com.earth2me.essentials.I18n;
import com.earth2me.essentials.IEssentials;
import com.earth2me.essentials.User;
import com.earth2me.essentials.Util;
import com.earth2me.essentials.commands.NoChargeException;
import com.earth2me.essentials.craftbukkit.InventoryWorkaround;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

public class Kit {
    public Kit() {
    }

    public static String listKits(IEssentials ess, User user) throws Exception {
        try {
            ConfigurationSection ex = ess.getSettings().getKits();
            StringBuilder list = new StringBuilder();
            Iterator var4 = ex.getKeys(false).iterator();

            while(true) {
                String kiteItem;
                do {
                    if(!var4.hasNext()) {
                        return list.toString().trim();
                    }

                    kiteItem = (String)var4.next();
                } while(user != null && !user.isAuthorized("essentials.kit." + kiteItem.toLowerCase(Locale.ENGLISH)));

                if(!canUse(user, kiteItem, ess.getSettings().getKit(kiteItem)))
                {
                    kiteItem = ChatColor.STRIKETHROUGH + kiteItem;
                }

                list.append(" ").append(I18n.capitalCase(kiteItem));
            }
        } catch (Exception var6) {
            throw new Exception(I18n._("kitError", new Object[0]), var6);
        }
    }

    public static boolean canUse(User user, String kitName, Map<String, Object> els)
    {
        GregorianCalendar time = new GregorianCalendar();
        double delay = els.containsKey("delay")?((Number)els.get("delay")).doubleValue():0.0D;
        GregorianCalendar earliestTime = new GregorianCalendar();
        earliestTime.add(13, -((int)delay));
        earliestTime.add(14, -((int)(delay * 1000.0D % 1000.0D)));
        long earliestLong = earliestTime.getTimeInMillis();
        Long lastTime = user.getKitTimestamp(kitName);

        if(lastTime != null && lastTime.longValue() >= earliestLong && !user.getPlayer().hasPermission("essentials.kit.notimer"))
        {
            if(lastTime.longValue() <= time.getTimeInMillis())
            {
                return false;
            }
        }

        return true;
    }

    public static void checkTime(User user, String kitName, Map<String, Object> els) throws NoChargeException {
        GregorianCalendar time = new GregorianCalendar();
        double delay = els.containsKey("delay")?((Number)els.get("delay")).doubleValue():0.0D;
        GregorianCalendar earliestTime = new GregorianCalendar();
        earliestTime.add(13, -((int)delay));
        earliestTime.add(14, -((int)(delay * 1000.0D % 1000.0D)));
        long earliestLong = earliestTime.getTimeInMillis();
        Long lastTime = user.getKitTimestamp(kitName);
        if(lastTime != null && lastTime.longValue() >= earliestLong && !user.getPlayer().hasPermission("essentials.kit.notimer")) {
            if(lastTime.longValue() <= time.getTimeInMillis()) {
                time.setTimeInMillis(lastTime.longValue());
                time.add(13, (int)delay);
                time.add(14, (int)(delay * 1000.0D % 1000.0D));
                user.sendMessage(I18n._("kitTimed", new Object[]{Util.formatDateDiff(time.getTimeInMillis())}));
                throw new NoChargeException();
            }

            user.setKitTimestamp(kitName, time.getTimeInMillis());
        } else {
            user.setKitTimestamp(kitName, time.getTimeInMillis());
        }

    }

    public static List<String> getItems(User user, Map<String, Object> kit) throws Exception {
        if(kit == null) {
            throw new Exception(I18n._("kitError2", new Object[0]));
        } else {
            try {
                return (List)kit.get("items");
            } catch (Exception var3) {
                user.sendMessage(I18n._("kitError2", new Object[0]));
                throw new Exception(I18n._("kitErrorHelp", new Object[0]), var3);
            }
        }
    }

    public static void expandItems(IEssentials ess, User user, List<String> items) throws Exception {
        try {
            boolean e = false;
            Iterator var4 = items.iterator();

            while(var4.hasNext()) {
                String d = (String)var4.next();
                String[] parts = d.split(" ");
                String[] item = parts[0].split("[:+\',;.]", 2);
                int id = Material.getMaterial(Integer.parseInt(item[0])).getId();
                short data = item.length > 1?Short.parseShort(item[1]):0;
                int amount = parts.length > 1?Integer.parseInt(parts[1]):1;
                ItemStack stack = new ItemStack(id, amount, data);
                if(parts.length > 2) {
                    for(int overfilled = 2; overfilled < parts.length; ++overfilled) {
                        String[] split = parts[overfilled].split("[:+\',;.]", 2);
                        if(split.length >= 1) {
                            Enchantment itemStack = Enchantments.getByName(split[0]);
                            if(itemStack == null) {
                                throw new Exception("Enchantment not found: " + split[0]);
                            }

                            int level;
                            if(split.length > 1) {
                                level = Integer.parseInt(split[1]);
                            } else {
                                level = itemStack.getMaxLevel();
                            }

                            try {
                                stack.addEnchantment(itemStack, level);
                            } catch (Exception var17) {
                                throw new Exception("Enchantment " + itemStack.getName() + ": " + var17.getMessage(), var17);
                            }
                        }
                    }
                }

                Map var19;
                if(user.isAuthorized("essentials.oversizedstacks")) {
                    var19 = InventoryWorkaround.addItem(user.getInventory(), true, ess.getSettings().getOversizedStackSize(), new ItemStack[]{stack});
                } else {
                    var19 = InventoryWorkaround.addItem(user.getInventory(), true, 0, new ItemStack[]{stack});
                }

                for(Iterator var20 = var19.values().iterator(); var20.hasNext(); e = true) {
                    ItemStack var21 = (ItemStack)var20.next();
                    user.getWorld().dropItemNaturally(user.getLocation(), var21);
                }
            }

            user.updateInventory();
            if(e) {
                user.sendMessage(I18n._("kitInvFull", new Object[0]));
            }

        } catch (Exception var18) {
            user.updateInventory();
            if(ess.getSettings().isDebug()) {
                ess.getLogger().log(Level.WARNING, var18.getMessage());
            } else {
                ess.getLogger().log(Level.WARNING, var18.getMessage());
            }

            throw new Exception(I18n._("kitError2", new Object[0]), var18);
        }
    }
}
